import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./registerServiceWorker";
import VueEvents from 'vue-events'
import VModal from 'vue-js-modal'

//Vue.use(VModal)
Vue.use(VModal, { dynamic: true })
Vue.use(VueEvents)
/* template files */

// import tpl_jqrymin from './assets/template_files/plugins/jquery/jquery.min.js';
// import tpl_bootstap from './assets/template_files/plugins/bootstrap/js/bootstrap.js';
// import tpl_waves from './assets/template_files/plugins/node-waves/waves.js';
// import tpl_adminjs from './assets/template_files/js/admin.js';



Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
