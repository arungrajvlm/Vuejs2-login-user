import Vue from "vue";
import Router from "vue-router";
import Login from "./components/auth/Login.vue";
import Dashboard from "./components/Dashboard.vue";
import Users from "./components/Users.vue";
import UsersApiMode from "./components/UsersApiMode.vue";
import Myvuetable from "./components/MyVuetable.vue";
import ForgotPassword from "./components/auth/forgotPassword.vue";
import UserManager from "./components/users/userMngr.vue";
import resetPassword from "./components/auth/resetPassword.vue";





Vue.use(Router);

export default new Router({
  mode: "history",
  base: process.env.BASE_URL,
  routes: [
    {
      path: "/",
      name: "login",
      component: Login
    },
    {
      path: "/forgot-password",
      name: "forgotPassword",
      component: ForgotPassword
    },
    {
      path: "/reset-password",
      name: "resetPassword",
      component: resetPassword
    },
    
    {
      path: "/dashboard",
      name: "dashboard",
      component: Dashboard
    },
    {
      path: "/users",
      name: "users",
      component: Users
    },
    {
      path: "/user-manager",
      name:"usermanager",
      component: UserManager
    },
    {
      path: "/users_api_mode",
      name: "usersapimode",
      component: UsersApiMode
    },
    {
      path: "/myvuetable",
      name: "myvuetable",
      component: Myvuetable
    },
    {
      path: "/about",
      name: "about",
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () =>
        import(/* webpackChunkName: "about" */ "./views/About.vue")
    }
  ]
});
