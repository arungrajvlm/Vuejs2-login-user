import VuetableFieldCheckbox from "vuetable-2/src/components/VuetableFieldCheckbox.vue";

export default [
 
 
 
  {
    name: "FULL_NAME",
    title: 'Name',
    sortField: "FULL_NAME"
  },
  {
    name: "USER_EMAIL",
    title: '<span class="orange glyphicon glyphicon-user"></span> Email Address',
    sortField: "USER_EMAIL"
  },
  {
    name: "GENDER",
    formatter: value => {
      return value === "M" ? "Male" : "Female";
    }
  },
  {
    name: "USER_ROLE",
    title: 'User Type',
    sortField: "USER_ROLE"
  },
  {
    name: "LAST_LOGIN_IP",
    title: 'Last Login IP',
    sortField: "LAST_LOGIN_IP"
  },
  "active",
  "actions"
];
