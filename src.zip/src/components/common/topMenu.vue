<template>
<nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                  <router-link to="/">Home</router-link> |
                  <router-link to="/myvuetable">Vue-table2 API mode</router-link> | 
                  <router-link to="/users">Vue-table2</router-link> | 
                  <router-link to="/about">About</router-link>
            </div>
        </div>
</nav>   
</template>

<script>
export default {
         beforeCreate() {
             document.body.className = document.body.className.replace("login-page","");
             document.body.className = document.body.className.replace("ls-closed","");
              
        }
}
</script>
