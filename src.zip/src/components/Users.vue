<template>
<div class="container-fluid">
<div class="row clearfix">
  <div class="row clearfix">
                <div class="col-xs-12 col-sm-9">
                    <div class="card">
                      <button @click="searchUser">User</button>
                        <div class="preloader" v-if="loading"> 
                            <div class="spinner-layer pl-teal">
                                <div class="circle-clipper left">
                                    <div class="circle"></div>
                                </div>
                                <div class="circle-clipper right">
                                    <div class="circle"></div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive" v-else>

      <vuetable ref="vuetable"
			:api-mode="false"
			:fields="fields"
      :per-page="perPage"
      :multi-sort="true"
			:data-manager="dataManager"
      pagination-path="pagination"
      :css="css.table"
	    @vuetable:pagination-data="onPaginationData"
		>
        
    <div slot="active" slot-scope="props">
      <div class="switch">
                                    <label>OFF<input type="checkbox" checked=""><span class="lever"></span>ON</label>
                                </div>
	</div>
			<div slot="actions" slot-scope="props">
<button type="button" class="btn bg-red waves-effect">
                                    <i class="material-icons bg-red waves-effect">delete</i>
                                </button> &nbsp;
                                <button type="button" class="btn bg-orange waves-effect">
                                    <i class="material-icons">edit</i>
                                </button>
			</div>
	
		</vuetable>
        <div style="padding-top:10px;padding-right:10px;">
      <vuetable-pagination ref="pagination"
       :css="css.pagination"
        @vuetable-pagination:change-page="onChangePage"
      ></vuetable-pagination>
    </div>
    </div>
                    </div>
                </div>
                                <div class="col-xs-12 col-sm-3">
                    <div class="card profile-card">
                       <!-- <div class="profile-header"> Add User</div> -->
                        <div class="profile-body">
                            <div class="content-area">
                                <b>ADD USER</b>
                                <p>Add New Users to portal</p>
                            </div>
                        </div>
                        <div class="profile-footer">
                            <ul>
                                <li><div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" id="email_address" class="form-control">
                                        <label class="form-label">Email Address</label>
                                    </div>
                                </div></li>
                            </ul>
                            <button class="btn btn-primary btn-lg waves-effect btn-block">Save</button>
                        </div>
                    </div>

                    
                </div>
            </div>
  		
    
                            </div>
</div>
</template>

<script>
import Vuetable from "vuetable-2";
import VuetableCssBootstrap from './VuetableCssBootstrap3.js'
import VuetablePagination from "vuetable-2/src/components/VuetablePagination";
import FieldsDef from "./FieldsDef.js";
import axios from "axios";
import _ from "lodash";


export default {
  components: {
    Vuetable,
    VuetablePagination
  },
   data() {
    return { 
      fields: FieldsDef,     
      perPage: 3,
      data: [],
      css: VuetableCssBootstrap,
      loading:1,
    };
  },
   

  mounted() {
    axios.get("http://helpbroin.000webhostapp.com/tools/vue_api/?apikey=api@2150&action=getUser").then(response => {
      this.data = response.data.data;
      this.loading = 0;
    });
  },

    methods: {
    searchUser(){
      axios.get("http://helpbroin.000webhostapp.com/tools/vue_api/?apikey=api@2150&action=getUser&filter=ar").then(response => {
      this.data = response.data.data;
      this.loading = 0;
      //this.dataManager();
      this.$refs.vuetable.refresh() 
    });
    },  
    onPaginationData(paginationData) {
      this.$refs.pagination.setPaginationData(paginationData);
    },
    onChangePage(page) {
      this.$refs.vuetable.changePage(page);
    },
    dataManager(sortOrder, pagination) {
      if (this.data.length < 1) return;

      let local = this.data;

      // sortOrder can be empty, so we have to check for that as well
      if (sortOrder.length > 0) {
        console.log("orderBy:", sortOrder[0].sortField, sortOrder[0].direction);
        local = _.orderBy(
          local,
          sortOrder[0].sortField,
          sortOrder[0].direction
        );
      }

      pagination = this.$refs.vuetable.makePagination(
        local.length,
        this.perPage
      );
      console.log('pagination:', pagination)
      let from = pagination.from - 1;
      let to = from + this.perPage;

      return {
        pagination: pagination,
        data: _.slice(local, from, to)
      };
    },
    onActionClicked(action, data) {
      console.log("slot actions: on-click", data.name);
    }
  }
}
</script>
<style scoped>
.profile-body{
  padding-top: 15px;
}
.vuetable-pagination {  
    margin-bottom: 10px;
}
</style>
