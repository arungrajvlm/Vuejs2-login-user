<template>
  <div id="app" class="ui container">
    <h1>&lt;Vuetable-2&gt;</h1>
    <div class="table-responsive">
    <vuetable
      api-url="https://vuetable.ratiw.net/api/users"
      :fields="fields"
      data-path="data"
      pagination-path=""
      :css="css.table"
    ></vuetable>
    </div>
         <div style="padding-top:10px">
      <vuetable-pagination ref="pagination"
        @vuetable-pagination:change-page="onChangePage"
      ></vuetable-pagination>
    </div>
  </div>
</template>

<script>
import Vuetable from "vuetable-2";
import VuetableCssBootstrap from './VuetableCssBootstrap3.js'
import FieldsDef from "./FieldsDef.js";

export default {
  name: "App",
  components: {
    Vuetable
  },
  data() {
    return {
     fields: FieldsDef,
      css: VuetableCssBootstrap
    };
  }
};
</script>

<style>

.vuetable-head-wrapper > table.vuetable {
  margin-bottom: 0px;
}
.vuetable tbody td {
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
