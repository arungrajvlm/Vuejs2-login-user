<template>
 
<div class="login-box login-page animated  bounceInDown">
      <div class="logo">
          <a href="javascript:void(0);">Admin<b>BSB</b></a>
          <small>Admin BootStrap Based - Material Design</small>
      </div>
      <div class="card">
               
            <div class="body">
                <form id="forgot_password" @submit="validateSubmitForm"> 
 
                    <div class="msg">
                        Enter your email address that you used to register. We'll send you an email with your username and a
                        link to reset your password.
                        <p v-if="errors.length">
                            <b>Please correct the following error(s):</b>
                            <ul>
                                <li v-for="error in errors">{{ error }}</li>
                            </ul>
                        </p>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                        <div class="form-line">
                            <input type="email" class="form-control" name="email" placeholder="Email" v-model="email" >
                        </div>
                    </div>

                    <button class="btn btn-block btn-lg bg-pink waves-effect" type="submit">RESET MY PASSWORD</button>

                    <div class="row m-t-20 m-b--5 align-center">
                         <router-link to="/">Sign In!</router-link>
                    </div>
                </form>
            </div>
        
      </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
    data(){
        return{
            errors:[],
            email:null
       }
    },
    methods:{
        forgotPasswordSubmit: function(e) {

            axios
                .get("http://helpbroin.000webhostapp.com/tools/vue_api/?apikey=api@2150&action=resetPass&email="+this.email, {
                })
                .then(res => {
                if (res.data.success) {
                    //alert("SuccEss");
                    this.$router.push('reset-password') 
                } else {
                    console.log("No Data");
                }
                })
                .catch(err => {
                alert(err);
                //console.log(" Login Webservice  Error :" + err);
                });
        },
        validateSubmitForm: function(e) {
            this.errors = [];
            if(!this.email) {  
                this.errors.push("Email required.");
            } else if(!this.validEmail(this.email)) {
                this.errors.push("Valid email required.");        
            }
            if(!this.errors.length) {
                e.preventDefault();
                this.forgotPasswordSubmit();               
            }
            e.preventDefault();
            },
        validEmail:function(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        },
    },
     beforeCreate() {
            document.body.className = 'login-page ls-closed';
        }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
