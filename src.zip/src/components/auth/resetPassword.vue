<template>
 
<div class="login-box login-page animated  bounceInDown">
      <div class="logo">
          <a href="javascript:void(0);">Admin<b>BSB</b></a>
          <small>Admin BootStrap Based - Material Design</small>
      </div>
      <div class="card">
 

           <div class="body" v-if="resetdone">
               <transition
               enter-active-class="animated shake" 
               ><div>
                Password Reset  completed.... Please login with new password
                <div class="row m-t-20 m-b--5 align-center">
                         <router-link to="/">Sign In!</router-link>
                    </div>
                    </div>
               </transition>
           </div>     
            <div class="body" v-else>
                <form id="forgot_password" @submit="validateSubmitForm"> 
 
                    <div class="msg">
                       Please Enter the details Received in Email
                       <transition
               enter-active-class="animated shake" 
               >
                        <p v-if="errors.length" class="alert alert-danger">
                            <b>Please correct the following error(s):</b>
                            <ul>
                                <li v-for="error in errors">{{ error }}</li>
                            </ul>
                        </p>
                       </transition>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                        <div class="form-line">
                            <input type="email" class="form-control" name="email" placeholder="Email" v-model="email" >
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="securekey" placeholder="Secure Key" v-model="securekey" >
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">email</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="resetpassword" placeholder="New Password" v-model="password" >
                        </div>
                    </div>

                    <button class="btn btn-block btn-lg bg-pink waves-effect" type="submit">RESET MY PASSWORD</button>

                    <div class="row m-t-20 m-b--5 align-center">
                         <router-link to="/">Sign In!</router-link>
                    </div>
                </form>
            </div>
        
      </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
    data(){
        return{
            errors:[],
            email:null,
            securekey:null,
            password:null,
            resetdone:0,
            animate:0
       }
    },
    methods:{
        forgotPasswordSubmit: function(e) {

            axios
                .get("http://helpbroin.000webhostapp.com/tools/vue_api/?apikey=api@2150&action=resetPass&email="+this.email, {
                })
                .then(res => {
                if (res.data.success) {
                    //alert("Success");
                    this.resetdone = 1;
                } else {
                    console.log("No Data");
                }
                })
                .catch(err => {
                alert(err);
                //console.log(" Login Webservice  Error :" + err);
                });
        },
        validateSubmitForm: function(e) {
            this.errors = [];
            if(!this.email) {  
                this.errors.push("Email required.");
            } else if(!this.validEmail(this.email)) {
                this.errors.push("Valid email required.");        
            }
            if(!this.errors.length) {
                e.preventDefault();
                this.forgotPasswordSubmit();               
            }
            e.preventDefault();
            },
        validEmail:function(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        },
    },
     beforeCreate() {
            document.body.className = 'login-page ls-closed';
        }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
