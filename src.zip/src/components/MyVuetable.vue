<template>
<div class="container-fluid">
<div class="row clearfix">
  

    
    <select v-model="noOfRecordsPerPage" class="pull-right">
       <option value="5">5</option>
       <option value="10">10</option>
       <option value="20">20</option>
       <option value="50">50</option>
    </select>
    <filter-bar></filter-bar>
    <div class="preloader" v-show="loadingGridData"> 
          <div class="spinner-layer pl-teal">
              <div class="circle-clipper left">
                  <div class="circle"></div>
              </div>
              <div class="circle-clipper right">
                  <div class="circle"></div>
              </div>
          </div>
      </div>
      <div class="table-responsive" v-show="!loadingGridData">
          <vuetable ref="vuetable"
            api-url="http://helpbroin.000webhostapp.com/tools/vue_api/?apikey=api@2150&action=getUser"
            :fields="fields"
            :css="css.table"
            pagination-path=""
            :per-page="noOfRecordsPerPage"
            :multi-sort="true"
            :sort-order="sortOrder"
            :append-params="moreParams"
            @vuetable:pagination-data="onPaginationData"
            @vuetable:loading="showLoader"
            @vuetable:loaded="hideLoader"
              >
      
          <div slot="active" slot-scope="props">
      <div class="switch">
                                    <label>OFF<input type="checkbox" checked=""><span class="lever"></span>ON</label>
                                </div>
	</div>
			<div slot="actions" slot-scope="props">
<button type="button" class="btn bg-red waves-effect">
                                    <i class="material-icons bg-red waves-effect">delete</i>
                                </button> &nbsp;
                                <button type="button" class="btn bg-orange waves-effect">
                                    <i class="material-icons">edit</i>
                                </button>
			</div>
        </vuetable> 
     
    
   <div style="padding-top:10px;padding-right:10px;">
      <vuetable-pagination ref="pagination"
       :css="css.pagination"
        @vuetable-pagination:change-page="onChangePage"
      ></vuetable-pagination>
       <vuetable-pagination-info ref="paginationInfo"
      ></vuetable-pagination-info>
    </div>

 </div> 
  </div>
</div>
</template>

<script>
//import accounting from 'accounting'
//import moment from 'moment'
import Vue from 'vue'
import VueEvents from 'vue-events'
import Vuetable from 'vuetable-2/src/components/Vuetable'
import VuetablePagination from 'vuetable-2/src/components/VuetablePagination'
import VuetableCssBootstrap from './VuetableCssBootstrap3.js'
import VuetablePaginationInfo from 'vuetable-2/src/components/VuetablePaginationInfo'
import CustomActions from './CustomActions'
import DetailRow from './DetailRow'
import FieldsDef from "./FieldsDef.js";
import FilterBar from './FilterBar'

Vue.use(VueEvents)
Vue.component('custom-actions', CustomActions)
Vue.component('my-detail-row', DetailRow)
Vue.component('filter-bar', FilterBar)

export default {
  components: {
    Vuetable,
    VuetablePagination,
    VuetablePaginationInfo
  },
  data () {
    return {
       css: VuetableCssBootstrap,
       fields: FieldsDef,  
       sortOrder: [
        {
          field: 'FULL_NAME',
          sortField: 'FULL_NAME',
          direction: 'asc'
        }
      ],
      moreParams: {},
      loadingGridData:0,
      noOfRecordsPerPage:3
    }
  },
  mounted () {
    this.$events.$on('filter-set', eventData => this.onFilterSet(eventData))
    this.$events.$on('filter-reset', e => this.onFilterReset())
  },
  methods: {
    allcap (value) {
      return value.toUpperCase()
    },
    genderLabel (value) {
      return value === 'M'
        ? '<span class="ui teal label"><i class="large man icon"></i>Male</span>'
        : '<span class="ui pink label"><i class="large woman icon"></i>Female</span>'
    },
    formatNumber (value) {
      return accounting.formatNumber(value, 2)
    },
    formatDate (value, fmt = 'D MMM YYYY') {
      return (value == null)
        ? ''
        : moment(value, 'YYYY-MM-DD').format(fmt)
    },
    onPaginationData (paginationData) {
      this.$refs.pagination.setPaginationData(paginationData)
      this.$refs.paginationInfo.setPaginationData(paginationData)
    },
    onChangePage (page) {
      this.$refs.vuetable.changePage(page)
    },
    onAction (action, data, index) {
      console.log('slot action: ' + action, data.name, index)
    },
    // onCellClicked (data, field, event) {
    //   console.log('cellClicked: ', field.name)
    //   this.$refs.vuetable.toggleDetailRow(data.id)
    // },
    onFilterSet (filterText) {
      this.moreParams.filter = filterText
      Vue.nextTick( () => this.$refs.vuetable.refresh() )
    },
    onFilterReset () {
      delete this.moreParams.filter
      Vue.nextTick( () => this.$refs.vuetable.refresh() )
    },
    showLoader(){
      this.loadingGridData = 1;
      console.log("Loading");
    },
    hideLoader(){
      this.loadingGridData = 0;
      console.log("Loaded");
    }
  }
}
</script>
